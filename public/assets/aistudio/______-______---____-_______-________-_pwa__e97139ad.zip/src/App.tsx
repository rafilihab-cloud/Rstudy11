import React, { useState } from 'react';
import { SchoolProvider, useSchool } from './context/SchoolContext';
import { Navbar } from './components/layout/Navbar';
import { MobileTabBar } from './components/layout/MobileTabBar';
import { OfflineIndicator } from './components/pwa/OfflineIndicator';
import { TeacherDashboard } from './components/teacher/TeacherDashboard';
import { StudentDashboard } from './components/student/StudentDashboard';
import { ParentDashboard } from './components/parent/ParentDashboard';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { SuperAdminDashboard } from './components/superadmin/SuperAdminDashboard';
import { ScheduleView } from './components/shared/ScheduleView';
import { MessagingView } from './components/shared/MessagingView';
import { ReportCardModal } from './components/shared/ReportCardModal';
import { HonorRollModal } from './components/shared/HonorRollModal';
import { Sparkles, Crown } from 'lucide-react';

const MainAppContent: React.FC = () => {
  const { currentRole, students, currentUser, activeChildId, language, t } = useSchool();
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [deviceMode, setDeviceMode] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');

  // Modals
  const [isReportCardOpen, setIsReportCardOpen] = useState(false);
  const [isHonorRollOpen, setIsHonorRollOpen] = useState(false);

  // Student to show on report card
  const activeStudent =
    currentRole === 'parent'
      ? students.find((s) => s.id === activeChildId) || students[0]
      : students.find((s) => s.id === currentUser.id) || students[0];

  const renderContent = () => {
    // Super Admin has full central command dashboard
    if (currentRole === 'super_admin') {
      if (activeTab === 'messages') {
        return <MessagingView />;
      }
      return <SuperAdminDashboard />;
    }

    // If user clicked direct tab
    if (activeTab === 'schedule') {
      return <ScheduleView />;
    }
    if (activeTab === 'messages') {
      return <MessagingView />;
    }

    // Role specific dashboard
    switch (currentRole) {
      case 'teacher':
        return <TeacherDashboard />;
      case 'student':
        return <StudentDashboard onOpenReportCard={() => setIsReportCardOpen(true)} />;
      case 'parent':
        return (
          <ParentDashboard
            onOpenReportCard={() => setIsReportCardOpen(true)}
            onNavigateToMessages={() => setActiveTab('messages')}
          />
        );
      case 'admin':
      default:
        return <AdminDashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col text-slate-800">
      {/* PWA Offline indicator */}
      <OfflineIndicator />

      {/* Main Global Header */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        deviceMode={deviceMode}
        setDeviceMode={setDeviceMode}
        onOpenReportCard={() => setIsReportCardOpen(true)}
        onOpenHonorRoll={() => setIsHonorRollOpen(true)}
      />

      {/* Quick Role Navigation Subheader for Tablet/Desktop */}
      <div className="bg-white border-b border-slate-200/80 px-4 py-2 hidden md:block no-print">
        <div className="max-w-7xl mx-auto flex items-center justify-between text-xs">
          <div className="flex items-center gap-1 font-bold text-slate-600">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`px-3 py-1.5 rounded-lg transition ${
                activeTab === 'dashboard'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'hover:bg-slate-100 text-slate-700'
              }`}
            >
              {currentRole === 'super_admin' ? t('superAdminPortal') : t('home')}
            </button>
            {currentRole !== 'super_admin' && (
              <button
                onClick={() => setActiveTab('schedule')}
                className={`px-3 py-1.5 rounded-lg transition ${
                  activeTab === 'schedule'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'hover:bg-slate-100 text-slate-700'
                }`}
              >
                {t('schedule')}
              </button>
            )}
            <button
              onClick={() => setActiveTab('messages')}
              className={`px-3 py-1.5 rounded-lg transition ${
                activeTab === 'messages'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'hover:bg-slate-100 text-slate-700'
              }`}
            >
              {t('messages')}
            </button>
            {currentRole === 'super_admin' && (
              <span className="mx-2 px-2.5 py-0.5 rounded-md bg-amber-50 text-amber-800 border border-amber-200/80 text-[11px] font-black flex items-center gap-1">
                <Crown className="w-3 h-3 text-amber-600" />
                <span>{language === 'ar' ? 'صلاحيات المالك الكاملة' : 'Full Owner Privileges'}</span>
              </span>
            )}
          </div>

          <div className="flex items-center gap-3 text-slate-500 font-semibold">
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              {t('onlineSync')}
            </span>
            <button
              onClick={() => setIsHonorRollOpen(true)}
              className="text-amber-700 hover:text-amber-800 font-bold flex items-center gap-1"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{t('honorRoll')}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main View Area with Device Simulator Capability */}
      <main className="flex-1 p-3 sm:p-6 pb-24 md:pb-8 flex justify-center">
        {deviceMode === 'desktop' ? (
          <div className="w-full max-w-7xl">{renderContent()}</div>
        ) : deviceMode === 'tablet' ? (
          // Tablet Mockup
          <div className="w-full max-w-3xl bg-slate-900 p-4 rounded-[40px] shadow-2xl border-4 border-slate-700 my-2">
            <div className="flex items-center justify-center gap-2 mb-2 text-slate-400 text-xs font-mono">
              <div className="w-2.5 h-2.5 rounded-full bg-slate-700" />
              <span>
                {language === 'ar'
                  ? 'محاكي الجهاز اللوحي (iPad / Android Tablet)'
                  : 'Tablet Simulator (iPad / Android)'}
              </span>
            </div>
            <div className="bg-slate-50 rounded-[28px] p-4 min-h-[700px] max-h-[85vh] overflow-y-auto">
              {renderContent()}
            </div>
          </div>
        ) : (
          // Smartphone Mockup (PWA on Mobile)
          <div className="w-full max-w-sm bg-slate-900 p-3.5 rounded-[48px] shadow-2xl border-4 border-slate-700 my-2">
            {/* Phone Notch & Speaker */}
            <div className="flex items-center justify-center gap-3 mb-3">
              <div className="w-16 h-3 rounded-full bg-slate-800" />
              <div className="w-2.5 h-2.5 rounded-full bg-slate-800" />
            </div>
            {/* Screen */}
            <div className="bg-slate-50 rounded-[36px] p-3 min-h-[640px] max-h-[80vh] overflow-y-auto relative">
              {renderContent()}
            </div>
          </div>
        )}
      </main>

      {/* Native PWA Bottom Tab Bar for Mobile screens */}
      <MobileTabBar activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Printable Report Card Modal */}
      <ReportCardModal
        student={activeStudent}
        isOpen={isReportCardOpen}
        onClose={() => setIsReportCardOpen(false)}
      />

      {/* Honor Roll Modal */}
      <HonorRollModal isOpen={isHonorRollOpen} onClose={() => setIsHonorRollOpen(false)} />
    </div>
  );
};

export default function App() {
  return (
    <SchoolProvider>
      <MainAppContent />
    </SchoolProvider>
  );
}
