import React, { useState } from 'react';
import { useSchool } from '../../context/SchoolContext';
import { AttendanceStatus, GradeItem, Homework, FileAttachment } from '../../types';
import {
  CalendarCheck,
  Award,
  BookOpenCheck,
  Plus,
  Search,
  CheckCircle2,
  Clock,
  UserX,
  AlertTriangle,
  Check,
  Trash2,
  Eye,
  Paperclip,
  Image as ImageIcon,
  ExternalLink,
  X,
} from 'lucide-react';

export const TeacherDashboard: React.FC = () => {
  const {
    currentUser,
    students,
    grades,
    addGrade,
    deleteGrade,
    homeworkList,
    addHomework,
    gradeHomeworkSubmission,
    attendance,
    batchRecordAttendance,
    language,
    t,
  } = useSchool();

  const [activeSection, setActiveSection] = useState<'attendance' | 'grades' | 'homework'>(
    'attendance'
  );

  // Selected class
  const [selectedClass, setSelectedClass] = useState<string>('الصف الثالث المتوسط - أ');

  // Filtered students for class
  const classStudents = students.filter((s) => s.className === selectedClass);

  // --- Attendance State ---
  const todayStr = '2026-10-28';
  const [attendanceDate, setAttendanceDate] = useState<string>(todayStr);

  const [localAttendance, setLocalAttendance] = useState<
    Record<string, { status: AttendanceStatus; notes: string }>
  >(() => {
    const map: Record<string, { status: AttendanceStatus; notes: string }> = {};
    classStudents.forEach((std) => {
      const existing = attendance.find((a) => a.studentId === std.id && a.date === todayStr);
      map[std.id] = {
        status: existing ? existing.status : 'present',
        notes: existing?.notes || '',
      };
    });
    return map;
  });

  const [attendanceSavedToast, setAttendanceSavedToast] = useState(false);

  const handleStatusChange = (studentId: string, status: AttendanceStatus) => {
    setLocalAttendance((prev) => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        status,
      },
    }));
  };

  const handleNotesChange = (studentId: string, notes: string) => {
    setLocalAttendance((prev) => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        notes,
      },
    }));
  };

  const handleMarkAllPresent = () => {
    const updated: Record<string, { status: AttendanceStatus; notes: string }> = {};
    classStudents.forEach((std) => {
      updated[std.id] = {
        status: 'present',
        notes: '',
      };
    });
    setLocalAttendance(updated);
  };

  const handleSaveAttendance = () => {
    const records = classStudents.map((std) => ({
      date: attendanceDate,
      studentId: std.id,
      studentName: std.name,
      className: selectedClass,
      status: localAttendance[std.id]?.status || 'present',
      notes: localAttendance[std.id]?.notes || '',
      recordedBy: currentUser.name,
    }));

    batchRecordAttendance(records);
    setAttendanceSavedToast(true);
    setTimeout(() => setAttendanceSavedToast(false), 3500);
  };

  // --- Grades Publishing State ---
  const [isGradeModalOpen, setIsGradeModalOpen] = useState(false);
  const [gradeStudentId, setGradeStudentId] = useState(classStudents[0]?.id || 'std_1');
  const [gradeSubject, setGradeSubject] = useState('الرياضيات');
  const [gradeExamType, setGradeExamType] = useState<GradeItem['examType']>('اختبار نصفي');
  const [gradeScore, setGradeScore] = useState<number>(18);
  const [gradeMaxScore, setGradeMaxScore] = useState<number>(20);
  const [gradeFeedback, setGradeFeedback] = useState('');
  const [gradeSearch, setGradeSearch] = useState('');

  const handlePublishGrade = (e: React.FormEvent) => {
    e.preventDefault();
    const student = students.find((s) => s.id === gradeStudentId);
    if (!student) return;

    addGrade({
      studentId: student.id,
      studentName: student.name,
      className: student.className,
      subject: gradeSubject,
      examType: gradeExamType,
      score: Number(gradeScore),
      maxScore: Number(gradeMaxScore),
      term: 'الفصل الأول',
      date: new Date().toISOString().split('T')[0],
      feedback: gradeFeedback,
      gradedBy: currentUser.name,
    });

    setIsGradeModalOpen(false);
    setGradeFeedback('');
  };

  // --- Homework Management State with File/Photo Attachments ---
  const [isNewHwModalOpen, setIsNewHwModalOpen] = useState(false);
  const [hwTitle, setHwTitle] = useState('');
  const [hwDescription, setHwDescription] = useState('');
  const [hwSubject, setHwSubject] = useState('الرياضيات');
  const [hwDueDate, setHwDueDate] = useState('2026-11-04');
  const [hwMaxScore, setHwMaxScore] = useState(10);
  const [hwAttachments, setHwAttachments] = useState<FileAttachment[]>([]);

  const [selectedHwForSubmissions, setSelectedHwForSubmissions] = useState<Homework | null>(null);
  const [gradingSubmissionId, setGradingSubmissionId] = useState<string | null>(null);
  const [gradingScore, setGradingScore] = useState<number>(10);
  const [gradingTeacherNotes, setGradingTeacherNotes] = useState('');
  const [previewImageModal, setPreviewImageModal] = useState<string | null>(null);

  // File upload for new homework
  const handleTeacherFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      const isImg = file.type.startsWith('image/');
      reader.onload = (event) => {
        const url = event.target?.result as string;
        const newAttachment: FileAttachment = {
          id: `att_hw_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
          name: file.name,
          url,
          type: isImg ? 'image' : 'file',
          size: `${(file.size / 1024).toFixed(0)} KB`,
        };
        setHwAttachments((prev) => [...prev, newAttachment]);
      };
      reader.readAsDataURL(file);
    });
  };

  const handleAddSampleWorksheet = () => {
    setHwAttachments((prev) => [
      ...prev,
      {
        id: `att_sample_${Date.now()}`,
        name: language === 'ar' ? 'ورقة_عمل_المعادلات_والتمارين.png' : 'worksheet_equations.png',
        url: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=800&auto=format&fit=crop&q=80',
        type: 'image',
        size: '1.2 MB',
      },
    ]);
  };

  const handleCreateHomework = (e: React.FormEvent) => {
    e.preventDefault();
    if (!hwTitle.trim()) return;

    addHomework({
      title: hwTitle,
      description: hwDescription,
      subject: hwSubject,
      className: selectedClass,
      teacherId: currentUser.id,
      teacherName: currentUser.name,
      assignedDate: new Date().toISOString().split('T')[0],
      dueDate: hwDueDate,
      maxScore: Number(hwMaxScore),
      attachments: hwAttachments,
    });

    setIsNewHwModalOpen(false);
    setHwTitle('');
    setHwDescription('');
    setHwAttachments([]);
  };

  const handleGradeSubmission = (hwId: string, subId: string) => {
    gradeHomeworkSubmission(hwId, subId, Number(gradingScore), gradingTeacherNotes);
    setGradingSubmissionId(null);
    setGradingTeacherNotes('');
  };

  return (
    <div className="space-y-6">
      {/* Teacher Welcome Banner */}
      <div className="bg-gradient-to-r from-emerald-800 via-teal-800 to-slate-900 text-white p-6 rounded-3xl shadow-lg relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-200 border border-emerald-400/30">
                {t('teacherWelcome')}
              </span>
              <span className="text-xs text-emerald-300">{t('appName')}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black">
              {language === 'ar' ? currentUser.name : currentUser.nameEn || currentUser.name}
            </h1>
            <p className="text-xs sm:text-sm text-emerald-100/90 mt-1 max-w-xl">
              {language === 'ar' ? currentUser.title : currentUser.titleEn || currentUser.title}
            </p>
          </div>

          {/* Quick Stats */}
          <div className="flex items-center gap-3 bg-white/10 p-3 rounded-2xl border border-white/10 backdrop-blur-xs text-center">
            <div className="px-3 py-1 border-l border-white/20">
              <span className="text-lg font-black block">{classStudents.length}</span>
              <span className="text-[10px] text-emerald-200">{t('class')}</span>
            </div>
            <div className="px-3 py-1 border-l border-white/20">
              <span className="text-lg font-black block">{homeworkList.length}</span>
              <span className="text-[10px] text-emerald-200">{t('homeworkTab')}</span>
            </div>
            <div className="px-3 py-1">
              <span className="text-lg font-black block">{grades.length}</span>
              <span className="text-[10px] text-emerald-200">{t('publishGradesTab')}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Tabs Navigation */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto scrollbar-none">
        <button
          onClick={() => setActiveSection('attendance')}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition shrink-0 ${
            activeSection === 'attendance'
              ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
              : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <CalendarCheck className="w-4 h-4" />
          <span>{t('recordAttendanceTab')}</span>
        </button>

        <button
          onClick={() => setActiveSection('grades')}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition shrink-0 ${
            activeSection === 'grades'
              ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
              : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Award className="w-4 h-4" />
          <span>{t('publishGradesTab')}</span>
        </button>

        <button
          onClick={() => setActiveSection('homework')}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition shrink-0 ${
            activeSection === 'homework'
              ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
              : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <BookOpenCheck className="w-4 h-4" />
          <span>{t('homeworkTab')}</span>
        </button>
      </div>

      {/* SECTION 1: ATTENDANCE RECORDING */}
      {activeSection === 'attendance' && (
        <div className="space-y-4 animate-fadeIn">
          {/* Controls Bar */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-500 mb-1">
                  {t('class')}:
                </label>
                <select
                  value={selectedClass}
                  onChange={(e) => setSelectedClass(e.target.value)}
                  className="px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-800 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="الصف الثالث المتوسط - أ">الصف الثالث المتوسط - أ</option>
                  <option value="الصف الثالث المتوسط - ب">الصف الثالث المتوسط - ب</option>
                  <option value="الصف الأول المتوسط - ب">الصف الأول المتوسط - ب</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-500 mb-1">{t('date')}:</label>
                <input
                  type="date"
                  value={attendanceDate}
                  onChange={(e) => setAttendanceDate(e.target.value)}
                  className="px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-800 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleMarkAllPresent}
                className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition"
              >
                {t('markAllPresent')}
              </button>

              <button
                onClick={handleSaveAttendance}
                className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm shadow-md transition shadow-emerald-500/20 active:scale-95"
              >
                <Check className="w-4 h-4 stroke-[3]" />
                <span>{t('saveAttendance')}</span>
              </button>
            </div>
          </div>

          {attendanceSavedToast && (
            <div className="p-3 rounded-xl bg-emerald-100 text-emerald-900 border border-emerald-300 text-xs font-bold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>{t('attendanceSavedSuccess')}</span>
            </div>
          )}

          {/* Attendance Table */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-4">{t('studentRole')}</th>
                    <th className="py-3 px-4 text-center">{t('status')}</th>
                    <th className="py-3 px-4">{t('notes')}</th>
                    <th className="py-3 px-4 text-center">{t('totalAbsences')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {classStudents.map((std) => {
                    const currentStatus = localAttendance[std.id]?.status || 'present';
                    const currentNotes = localAttendance[std.id]?.notes || '';

                    return (
                      <tr key={std.id} className="hover:bg-slate-50/50 transition">
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-3">
                            <img
                              src={std.avatar}
                              alt={std.name}
                              className="w-9 h-9 rounded-full object-cover ring-1 ring-slate-200"
                            />
                            <div>
                              <span className="font-bold text-slate-900 text-sm block">
                                {language === 'ar' ? std.name : std.nameEn || std.name}
                              </span>
                              <span className="text-[10px] text-slate-400 font-mono">
                                {std.parentPhone}
                              </span>
                            </div>
                          </div>
                        </td>

                        <td className="py-3 px-4">
                          <div className="flex items-center justify-center gap-1.5">
                            {/* Present */}
                            <button
                              type="button"
                              onClick={() => handleStatusChange(std.id, 'present')}
                              className={`px-3 py-1 rounded-lg text-xs font-bold transition flex items-center gap-1 ${
                                currentStatus === 'present'
                                  ? 'bg-emerald-600 text-white shadow-xs'
                                  : 'bg-slate-100 text-slate-600 hover:bg-emerald-50 hover:text-emerald-700'
                              }`}
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>{t('present')}</span>
                            </button>

                            {/* Absent */}
                            <button
                              type="button"
                              onClick={() => handleStatusChange(std.id, 'absent')}
                              className={`px-3 py-1 rounded-lg text-xs font-bold transition flex items-center gap-1 ${
                                currentStatus === 'absent'
                                  ? 'bg-rose-600 text-white shadow-xs'
                                  : 'bg-slate-100 text-slate-600 hover:bg-rose-50 hover:text-rose-700'
                              }`}
                            >
                              <UserX className="w-3.5 h-3.5" />
                              <span>{t('absent')}</span>
                            </button>

                            {/* Late */}
                            <button
                              type="button"
                              onClick={() => handleStatusChange(std.id, 'late')}
                              className={`px-3 py-1 rounded-lg text-xs font-bold transition flex items-center gap-1 ${
                                currentStatus === 'late'
                                  ? 'bg-amber-600 text-white shadow-xs'
                                  : 'bg-slate-100 text-slate-600 hover:bg-amber-50 hover:text-amber-700'
                              }`}
                            >
                              <Clock className="w-3.5 h-3.5" />
                              <span>{t('late')}</span>
                            </button>

                            {/* Excused */}
                            <button
                              type="button"
                              onClick={() => handleStatusChange(std.id, 'excused')}
                              className={`px-3 py-1 rounded-lg text-xs font-bold transition flex items-center gap-1 ${
                                currentStatus === 'excused'
                                  ? 'bg-blue-600 text-white shadow-xs'
                                  : 'bg-slate-100 text-slate-600 hover:bg-blue-50 hover:text-blue-700'
                              }`}
                            >
                              <AlertTriangle className="w-3.5 h-3.5" />
                              <span>{t('excused')}</span>
                            </button>
                          </div>
                        </td>

                        <td className="py-3 px-4">
                          <input
                            type="text"
                            value={currentNotes}
                            onChange={(e) => handleNotesChange(std.id, e.target.value)}
                            placeholder={t('notes')}
                            className="w-full px-3 py-1.5 rounded-lg border border-slate-200 text-xs focus:ring-1 focus:ring-emerald-500 focus:outline-none bg-slate-50 focus:bg-white"
                          />
                        </td>

                        <td className="py-3 px-4 text-center">
                          <span
                            className={`px-2 py-0.5 rounded-full font-bold text-xs ${
                              std.totalAbsences > 3
                                ? 'bg-rose-100 text-rose-800'
                                : 'bg-slate-100 text-slate-700'
                            }`}
                          >
                            {std.totalAbsences} {language === 'ar' ? 'أيام' : 'days'}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 2: GRADES PUBLISHING */}
      {activeSection === 'grades' && (
        <div className="space-y-4 animate-fadeIn">
          {/* Header & New Grade Button */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={gradeSearch}
                onChange={(e) => setGradeSearch(e.target.value)}
                placeholder={t('search')}
                className="w-full pl-3 pr-9 py-2 rounded-xl border border-slate-200 text-xs bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <button
              onClick={() => setIsGradeModalOpen(true)}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm shadow-md transition shadow-emerald-500/20"
            >
              <Plus className="w-4 h-4" />
              <span>{t('publishNewGrade')}</span>
            </button>
          </div>

          {/* Grades List Table */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-4">{t('studentRole')}</th>
                    <th className="py-3 px-4">{t('class')}</th>
                    <th className="py-3 px-4">{t('subject')}</th>
                    <th className="py-3 px-4">{t('examType')}</th>
                    <th className="py-3 px-4 text-center">{t('score')}</th>
                    <th className="py-3 px-4 text-center">{t('percentage')}</th>
                    <th className="py-3 px-4">{t('feedback')}</th>
                    <th className="py-3 px-4 text-center">{t('delete')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {grades
                    .filter(
                      (g) =>
                        g.studentName.includes(gradeSearch) ||
                        g.subject.includes(gradeSearch) ||
                        g.examType.includes(gradeSearch as any)
                    )
                    .map((item) => {
                      const pct = ((item.score / item.maxScore) * 100).toFixed(0);
                      return (
                        <tr key={item.id} className="hover:bg-slate-50/50 transition">
                          <td className="py-3 px-4 font-bold text-slate-900">{item.studentName}</td>
                          <td className="py-3 px-4 text-slate-500">{item.className}</td>
                          <td className="py-3 px-4 font-semibold text-emerald-800">
                            {language === 'ar' ? item.subject : item.subjectEn || item.subject}
                          </td>
                          <td className="py-3 px-4 text-slate-600">{item.examType}</td>
                          <td className="py-3 px-4 text-center font-black text-slate-900 text-sm">
                            {item.score} <span className="text-slate-400 text-xs">/ {item.maxScore}</span>
                          </td>
                          <td className="py-3 px-4 text-center">
                            <span
                              className={`px-2 py-0.5 rounded-full font-bold text-[11px] ${
                                Number(pct) >= 90
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : Number(pct) >= 75
                                  ? 'bg-blue-100 text-blue-800'
                                  : 'bg-amber-100 text-amber-800'
                              }`}
                            >
                              %{pct}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-slate-500 max-w-[200px] truncate">
                            {language === 'ar' ? item.feedback : item.feedbackEn || item.feedback || '—'}
                          </td>
                          <td className="py-3 px-4 text-center">
                            <button
                              onClick={() => deleteGrade(item.id)}
                              className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition"
                              title={t('delete')}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 3: HOMEWORK & SUBMISSIONS WITH FILE & PHOTO SUPPORT */}
      {activeSection === 'homework' && (
        <div className="space-y-4 animate-fadeIn">
          {/* Header & Add Button */}
          <div className="flex items-center justify-between bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">{t('homeworkTab')}</h3>
              <p className="text-xs text-slate-500">
                {language === 'ar'
                  ? 'إرسال الواجبات مع ملفات وصور الشرح، ومراجعة تسليمات وصور حلول الطلاب'
                  : 'Assign homework with worksheets & images, and review student solution photos'}
              </p>
            </div>
            <button
              onClick={() => setIsNewHwModalOpen(true)}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm shadow-md transition shadow-emerald-500/20"
            >
              <Plus className="w-4 h-4" />
              <span>{t('createNewHomework')}</span>
            </button>
          </div>

          {/* Homework Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {homeworkList.map((hw) => {
              const pendingCount = hw.submissions.filter((s) => s.status === 'pending').length;
              return (
                <div
                  key={hw.id}
                  className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs hover:border-emerald-500/50 transition flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
                        {hw.subject}
                      </span>
                      <span className="text-[11px] text-slate-400 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {t('dueDate')}: {hw.dueDate}
                      </span>
                    </div>

                    <h4 className="font-black text-slate-900 text-base mb-1">{hw.title}</h4>
                    <p className="text-xs text-slate-600 leading-relaxed mb-3">{hw.description}</p>

                    {/* Attached files by teacher */}
                    {hw.attachments && hw.attachments.length > 0 && (
                      <div className="mb-3 p-2 bg-slate-50 rounded-xl border border-slate-200/80 text-xs">
                        <span className="text-[10px] font-bold text-slate-500 block mb-1">
                          {t('attachedReferenceFile')}:
                        </span>
                        {hw.attachments.map((att) => (
                          <div
                            key={att.id}
                            onClick={() => setPreviewImageModal(att.url)}
                            className="flex items-center justify-between p-1 rounded-lg bg-white border border-slate-200 cursor-pointer hover:border-blue-400"
                          >
                            <span className="text-[11px] font-semibold text-blue-700 truncate">
                              📎 {att.name}
                            </span>
                            <span className="text-[10px] text-slate-400">{att.size}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                    <div className="text-xs font-semibold text-slate-500">
                      {t('submissions')}: <span className="font-bold text-slate-900">{hw.submissions.length}</span>
                      {pendingCount > 0 && (
                        <span className="text-amber-600 font-bold mr-2">
                          ({pendingCount} {t('pendingGrading')})
                        </span>
                      )}
                    </div>

                    <button
                      onClick={() => setSelectedHwForSubmissions(hw)}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-emerald-50 hover:text-emerald-700 text-slate-700 font-bold text-xs transition"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>{t('reviewSubmissions')}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* MODAL: Publish New Grade */}
      {isGradeModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-fadeIn">
          <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl p-6 border border-slate-100">
            <h3 className="font-black text-slate-900 text-lg mb-1">{t('publishNewGrade')}</h3>
            <p className="text-xs text-slate-500 mb-4">
              {language === 'ar'
                ? 'سيتم نشر هذه الدرجة فوراً في حساب الطالب وحساب ولي أمره'
                : 'This score will immediately appear in the student & parent portals'}
            </p>

            <form onSubmit={handlePublishGrade} className="space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t('studentRole')}:
                </label>
                <select
                  value={gradeStudentId}
                  onChange={(e) => setGradeStudentId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-bold bg-slate-50"
                >
                  {students.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.className})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">{t('subject')}:</label>
                  <select
                    value={gradeSubject}
                    onChange={(e) => setGradeSubject(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-bold bg-slate-50"
                  >
                    <option value="الرياضيات">{t('math')}</option>
                    <option value="العلوم الطبيعية">{t('science')}</option>
                    <option value="اللغة الإنجليزية">{t('english')}</option>
                    <option value="اللغة العربية">{t('arabic')}</option>
                    <option value="الحاسب والذكاء الاصطناعي">{t('computerScience')}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">{t('examType')}:</label>
                  <select
                    value={gradeExamType}
                    onChange={(e) => setGradeExamType(e.target.value as GradeItem['examType'])}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-bold bg-slate-50"
                  >
                    <option value="اختبار نصفي">{t('midtermExam')}</option>
                    <option value="اختبار نهائي">{t('finalExam')}</option>
                    <option value="اختبار قصير">{t('quiz')}</option>
                    <option value="واجب وتقييم مستمر">{t('continuousEvaluation')}</option>
                    <option value="مشروع عملي">{t('project')}</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">{t('score')}:</label>
                  <input
                    type="number"
                    min="0"
                    max={gradeMaxScore}
                    step="0.5"
                    value={gradeScore}
                    onChange={(e) => setGradeScore(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-bold bg-slate-50"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">{t('maxScore')}:</label>
                  <input
                    type="number"
                    min="1"
                    value={gradeMaxScore}
                    onChange={(e) => setGradeMaxScore(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-bold bg-slate-50"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t('feedback')}:</label>
                <textarea
                  rows={2}
                  value={gradeFeedback}
                  onChange={(e) => setGradeFeedback(e.target.value)}
                  placeholder="ملاحظات المعلم وتوجيهه..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs bg-slate-50 focus:bg-white"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow transition"
                >
                  {t('publishNewGrade')}
                </button>
                <button
                  type="button"
                  onClick={() => setIsGradeModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition"
                >
                  {t('cancel')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Create New Homework with File/Photo Attachment */}
      {isNewHwModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-fadeIn">
          <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl p-6 border border-slate-100 max-h-[90vh] overflow-y-auto">
            <h3 className="font-black text-slate-900 text-lg mb-1">{t('createNewHomework')}</h3>
            <p className="text-xs text-slate-500 mb-4">
              {language === 'ar'
                ? 'تكليف الطلاب بواجب جديد مع إمكانية إرفاق أوراق عمل وصور توضيحية'
                : 'Assign new homework with worksheet attachments or diagrams'}
            </p>

            <form onSubmit={handleCreateHomework} className="space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t('homeworkTitle')}:
                </label>
                <input
                  type="text"
                  value={hwTitle}
                  onChange={(e) => setHwTitle(e.target.value)}
                  placeholder="مثال: حل تمارين الدوال والرسوم البيانية"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-bold bg-slate-50"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t('homeworkDesc')}:
                </label>
                <textarea
                  rows={3}
                  value={hwDescription}
                  onChange={(e) => setHwDescription(e.target.value)}
                  placeholder="اكتب التوجيهات والصفحات المطلوبة..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs bg-slate-50"
                  required
                />
              </div>

              {/* ATTACH FILES / PHOTOS BY TEACHER */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <label className="block text-xs font-bold text-slate-700">
                  {t('attachments')}:
                </label>
                <div className="flex flex-wrap items-center gap-2">
                  <label className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-300 hover:border-emerald-500 rounded-lg text-xs font-bold text-slate-700 cursor-pointer transition">
                    <Paperclip className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{t('attachFile')}</span>
                    <input
                      type="file"
                      multiple
                      accept="image/*,.pdf,.doc,.docx"
                      onChange={handleTeacherFileChange}
                      className="hidden"
                    />
                  </label>

                  <button
                    type="button"
                    onClick={handleAddSampleWorksheet}
                    className="flex items-center gap-1 px-2.5 py-1.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-[11px] font-bold"
                  >
                    <ImageIcon className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{language === 'ar' ? '+ إرفاق ورقة عمل تجريبية' : '+ Sample Worksheet'}</span>
                  </button>
                </div>

                {hwAttachments.length > 0 && (
                  <div className="space-y-1 pt-1">
                    {hwAttachments.map((file) => (
                      <div
                        key={file.id}
                        className="flex items-center justify-between p-1.5 bg-white rounded-lg border border-slate-200 text-xs"
                      >
                        <span className="font-semibold text-slate-800 truncate text-[11px]">
                          📎 {file.name} ({file.size})
                        </span>
                        <button
                          type="button"
                          onClick={() =>
                            setHwAttachments((prev) => prev.filter((a) => a.id !== file.id))
                          }
                          className="p-1 text-slate-400 hover:text-rose-600"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">{t('subject')}:</label>
                  <select
                    value={hwSubject}
                    onChange={(e) => setHwSubject(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-bold bg-slate-50"
                  >
                    <option value="الرياضيات">{t('math')}</option>
                    <option value="العلوم الطبيعية">{t('science')}</option>
                    <option value="اللغة الإنجليزية">{t('english')}</option>
                    <option value="اللغة العربية">{t('arabic')}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">{t('dueDate')}:</label>
                  <input
                    type="date"
                    value={hwDueDate}
                    onChange={(e) => setHwDueDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-bold bg-slate-50"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">{t('maxScore')}:</label>
                  <input
                    type="number"
                    min="1"
                    value={hwMaxScore}
                    onChange={(e) => setHwMaxScore(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-bold bg-slate-50"
                    required
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow transition"
                >
                  {t('createNewHomework')}
                </button>
                <button
                  type="button"
                  onClick={() => setIsNewHwModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition"
                >
                  {t('cancel')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Review & Grade Student Submissions with Attached Photos/Files */}
      {selectedHwForSubmissions && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-fadeIn">
          <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl p-6 border border-slate-100 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div>
                <h3 className="font-black text-slate-900 text-base">
                  {selectedHwForSubmissions.title}
                </h3>
                <p className="text-xs text-slate-500">
                  {t('submissions')}: {selectedHwForSubmissions.submissions.length}
                </p>
              </div>
              <button
                onClick={() => setSelectedHwForSubmissions(null)}
                className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg transition"
              >
                {t('close')}
              </button>
            </div>

            {selectedHwForSubmissions.submissions.length === 0 ? (
              <div className="py-12 text-center text-slate-400 text-xs">
                {t('noSubmissionsYet')}
              </div>
            ) : (
              <div className="space-y-3">
                {selectedHwForSubmissions.submissions.map((sub) => (
                  <div
                    key={sub.id}
                    className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-2 text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-900 text-sm">{sub.studentName}</span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {sub.submittedAt}
                      </span>
                    </div>

                    {/* Student text answer */}
                    {sub.content && (
                      <div className="p-3 rounded-lg bg-white border border-slate-200/80 text-slate-700 leading-relaxed">
                        {sub.content}
                      </div>
                    )}

                    {/* INSPECT STUDENT'S ATTACHED SOLUTION PHOTOS & DOCUMENTS */}
                    {sub.attachments && sub.attachments.length > 0 && (
                      <div className="p-2.5 bg-blue-50/60 rounded-xl border border-blue-200/80 space-y-2">
                        <span className="text-[10px] font-bold text-blue-900 block">
                          {language === 'ar' ? 'الصور والملفات المرفقة من الطالب:' : 'Student attached solution images & files:'}
                        </span>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {sub.attachments.map((att) => (
                            <div
                              key={att.id}
                              onClick={() => setPreviewImageModal(att.url)}
                              className="flex items-center gap-2 p-2 bg-white rounded-lg border border-blue-200 cursor-pointer hover:border-blue-400 hover:shadow-xs transition"
                            >
                              {att.type === 'image' && att.url ? (
                                <img
                                  src={att.url}
                                  alt={att.name}
                                  className="w-10 h-10 rounded-md object-cover border border-slate-200 shrink-0"
                                />
                              ) : (
                                <Paperclip className="w-5 h-5 text-blue-600 shrink-0" />
                              )}
                              <div className="truncate flex-1">
                                <span className="font-bold text-blue-900 text-xs truncate block">
                                  {att.name}
                                </span>
                                <span className="text-[10px] text-slate-400">{att.size} • انقر للمعاينة</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Grading row */}
                    {sub.status === 'graded' ? (
                      <div className="flex items-center justify-between pt-2 text-xs border-t border-slate-200">
                        <span className="text-emerald-700 font-bold flex items-center gap-1">
                          <CheckCircle2 className="w-4 h-4" />
                          {t('gradedSuccess')}: {sub.score} / {sub.maxScore}
                        </span>
                        <span className="text-slate-500 italic">"{sub.teacherNotes}"</span>
                      </div>
                    ) : gradingSubmissionId === sub.id ? (
                      <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-200 space-y-2 mt-2">
                        <div className="flex items-center gap-2">
                          <label className="font-bold text-slate-700">{t('score')}:</label>
                          <input
                            type="number"
                            max={sub.maxScore}
                            min="0"
                            value={gradingScore}
                            onChange={(e) => setGradingScore(Number(e.target.value))}
                            className="w-20 px-2 py-1 rounded border border-slate-300 font-bold"
                          />
                          <span className="text-slate-400">/ {sub.maxScore}</span>
                        </div>
                        <input
                          type="text"
                          value={gradingTeacherNotes}
                          onChange={(e) => setGradingTeacherNotes(e.target.value)}
                          placeholder={t('feedback')}
                          className="w-full px-3 py-1.5 rounded border border-slate-300 text-xs"
                        />
                        <div className="flex gap-2">
                          <button
                            onClick={() =>
                              handleGradeSubmission(selectedHwForSubmissions.id, sub.id)
                            }
                            className="px-3 py-1 bg-emerald-600 text-white rounded font-bold hover:bg-emerald-700"
                          >
                            {t('save')}
                          </button>
                          <button
                            onClick={() => setGradingSubmissionId(null)}
                            className="px-3 py-1 bg-slate-200 text-slate-700 rounded font-bold"
                          >
                            {t('cancel')}
                          </button>
                        </div>
                      </div>
                    ) : (
                      <button
                        onClick={() => {
                          setGradingSubmissionId(sub.id);
                          setGradingScore(sub.maxScore);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs"
                      >
                        {t('gradeSubmission')}
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Image Preview Lightbox Modal */}
      {previewImageModal && (
        <div
          onClick={() => setPreviewImageModal(null)}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4 animate-fadeIn"
        >
          <div className="relative max-w-3xl w-full bg-white rounded-2xl overflow-hidden shadow-2xl p-2">
            <button
              onClick={() => setPreviewImageModal(null)}
              className="absolute top-4 left-4 p-2 bg-black/60 hover:bg-black text-white rounded-full transition"
            >
              <X className="w-5 h-5" />
            </button>
            <img
              src={previewImageModal}
              alt="Preview"
              className="w-full max-h-[80vh] object-contain rounded-xl"
            />
          </div>
        </div>
      )}
    </div>
  );
};
