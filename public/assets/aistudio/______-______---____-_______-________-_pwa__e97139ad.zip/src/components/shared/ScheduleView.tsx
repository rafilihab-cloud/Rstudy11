import React, { useState } from 'react';
import { useSchool } from '../../context/SchoolContext';
import { TimetableEntry } from '../../types';
import { Clock, Calendar, MapPin, User, BookOpen, Pencil, X, CheckCircle2, ShieldCheck } from 'lucide-react';

export const ScheduleView: React.FC = () => {
  const { timetable, currentRole, updateTimetableEntry, language, t } = useSchool();
  const [selectedDayIndex, setSelectedDayIndex] = useState<number>(0);
  const [editingPeriod, setEditingPeriod] = useState<TimetableEntry | null>(null);
  const [editSubject, setEditSubject] = useState('');
  const [editTeacher, setEditTeacher] = useState('');
  const [editRoom, setEditRoom] = useState('');
  const [editTimeSlot, setEditTimeSlot] = useState('');
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const daysArabic = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس'];
  const daysEnglish = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday'];

  const selectedDayAr = daysArabic[selectedDayIndex];

  const filteredEntries = timetable
    .filter((entry) => entry.day === selectedDayAr)
    .sort((a, b) => a.period - b.period);

  const handleOpenEdit = (p: TimetableEntry) => {
    setEditingPeriod(p);
    setEditSubject(p.subject);
    setEditTeacher(p.teacherName);
    setEditRoom(p.room);
    setEditTimeSlot(p.timeSlot);
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPeriod) return;

    updateTimetableEntry(editingPeriod.id, {
      subject: editSubject.trim(),
      subjectEn: editSubject.trim(),
      teacherName: editTeacher.trim(),
      room: editRoom.trim(),
      roomEn: editRoom.trim(),
      timeSlot: editTimeSlot.trim(),
    });

    setEditingPeriod(null);
    setToastMsg(language === 'ar' ? 'تم تحديث الحصة بنجاح' : 'Period updated successfully');
    setTimeout(() => setToastMsg(null), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Title & Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-gradient-to-r from-blue-900 to-indigo-900 text-white p-6 rounded-2xl shadow-lg">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Clock className="w-5 h-5 text-blue-300" />
            <h2 className="text-xl font-black">{t('weeklyTimetable')}</h2>
          </div>
          <p className="text-xs text-blue-200">
            {language === 'ar'
              ? 'مواعيد الحصص اليومية، القاعات الدراسية، والمعلمون المشرفون'
              : 'Daily schedule periods, assigned rooms, and teachers'}
          </p>
        </div>
        <div className="flex items-center gap-2 text-xs font-semibold bg-white/10 px-3 py-1.5 rounded-xl border border-white/20 self-start sm:self-auto">
          <Calendar className="w-4 h-4 text-amber-300" />
          <span>{language === 'ar' ? 'الفصل الدراسي الأول - 2026' : 'First Term - 2026'}</span>
        </div>
      </div>

      {/* Days Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {daysArabic.map((dayAr, index) => {
          const isSelected = selectedDayIndex === index;
          return (
            <button
              key={dayAr}
              onClick={() => setSelectedDayIndex(index)}
              className={`px-5 py-2.5 rounded-xl text-sm font-bold transition-all shrink-0 ${
                isSelected
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20'
                  : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              {language === 'ar' ? `يوم ${dayAr}` : daysEnglish[index]}
            </button>
          );
        })}
      </div>

      {/* Timetable Period Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredEntries.length === 0 ? (
          <div className="col-span-full bg-white p-8 rounded-2xl text-center text-slate-400 border border-slate-200">
            {language === 'ar' ? 'لا توجد حصص مجدولة لهذا اليوم.' : 'No scheduled periods for today.'}
          </div>
        ) : (
          filteredEntries.map((period) => (
            <div
              key={period.id}
              className="bg-white rounded-2xl p-5 border border-slate-200 hover:border-blue-400 hover:shadow-md transition group"
            >
              <div className="flex items-center justify-between mb-3">
                <span className="w-8 h-8 rounded-xl bg-blue-50 text-blue-700 font-black text-sm flex items-center justify-center border border-blue-200/60">
                  {period.period}
                </span>
                <span className="text-xs font-semibold text-slate-500 bg-slate-100 px-2.5 py-1 rounded-lg font-mono">
                  {period.timeSlot}
                </span>
              </div>

              <div className="space-y-2">
                <h4 className="font-extrabold text-slate-900 text-base group-hover:text-blue-600 transition flex items-center gap-1.5">
                  <BookOpen className="w-4 h-4 text-blue-500 shrink-0" />
                  <span>{language === 'ar' ? period.subject : period.subjectEn || period.subject}</span>
                </h4>

                <div className="flex items-center gap-2 text-xs text-slate-600">
                  <User className="w-3.5 h-3.5 text-slate-400" />
                  <span>{t('teacherRole')}: {period.teacherName}</span>
                </div>

                <div className="flex items-center gap-2 text-xs text-slate-600">
                  <MapPin className="w-3.5 h-3.5 text-slate-400" />
                  <span>{t('room')}: {language === 'ar' ? period.room : period.roomEn || period.room}</span>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                <span>{period.className}</span>
                {currentRole === 'admin' ? (
                  <button
                    onClick={() => handleOpenEdit(period)}
                    className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-purple-50 hover:bg-purple-100 text-purple-700 font-bold text-xs border border-purple-200 transition active:scale-95 shadow-xs"
                    title={language === 'ar' ? 'تعديل الحصة (خاص بمدير المدرسة)' : 'Edit Period (Principal Only)'}
                  >
                    <Pencil className="w-3 h-3 text-purple-600" />
                    <span>{language === 'ar' ? 'تعديل الحصة' : 'Edit Period'}</span>
                  </button>
                ) : (
                  <span className="text-emerald-600 font-semibold">
                    {language === 'ar' ? 'حصة مؤكدة' : 'Confirmed'}
                  </span>
                )}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Toast Notification */}
      {toastMsg && (
        <div className="fixed bottom-6 right-6 z-50 bg-emerald-700 text-white px-4 py-3 rounded-2xl shadow-xl flex items-center gap-2 border border-emerald-500 text-xs font-bold animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-200" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* QUICK EDIT PERIOD MODAL FOR PRINCIPAL */}
      {editingPeriod && currentRole === 'admin' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-purple-100 text-purple-700">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-base">
                    {language === 'ar' ? 'تعديل الحصة (صلاحية مدير المدرسة)' : 'Edit Period (Principal)'}
                  </h3>
                  <span className="text-[11px] text-purple-700 font-bold">
                    {language === 'ar' ? `الحصة ${editingPeriod.period} - يوم ${editingPeriod.day}` : `Period ${editingPeriod.period} - ${editingPeriod.day}`}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setEditingPeriod(null)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-3.5 mt-4 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  {language === 'ar' ? 'اسم المادة' : 'Subject'}
                </label>
                <input
                  type="text"
                  value={editSubject}
                  onChange={(e) => setEditSubject(e.target.value)}
                  required
                  className="w-full p-2.5 rounded-xl border border-slate-200 font-bold focus:outline-hidden focus:ring-2 focus:ring-purple-500/20"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  {language === 'ar' ? 'المعلم المشرف' : 'Teacher'}
                </label>
                <input
                  type="text"
                  value={editTeacher}
                  onChange={(e) => setEditTeacher(e.target.value)}
                  required
                  className="w-full p-2.5 rounded-xl border border-slate-200 font-semibold focus:outline-hidden focus:ring-2 focus:ring-purple-500/20"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">
                    {language === 'ar' ? 'القاعة' : 'Room'}
                  </label>
                  <input
                    type="text"
                    value={editRoom}
                    onChange={(e) => setEditRoom(e.target.value)}
                    required
                    className="w-full p-2.5 rounded-xl border border-slate-200 font-semibold"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">
                    {language === 'ar' ? 'التوقيت' : 'Time'}
                  </label>
                  <input
                    type="text"
                    value={editTimeSlot}
                    onChange={(e) => setEditTimeSlot(e.target.value)}
                    required
                    className="w-full p-2.5 rounded-xl border border-slate-200 font-mono font-bold"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingPeriod(null)}
                  className="px-4 py-2 rounded-xl bg-slate-100 text-slate-700 font-bold"
                >
                  {t('cancel')}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold shadow-md shadow-purple-700/20"
                >
                  {language === 'ar' ? 'حفظ التعديلات' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
