import React, { useState } from 'react';
import { useSchool } from '../../context/SchoolContext';
import { PWAInstallButton } from '../pwa/PWAInstallButton';
import { RoleSwitcherModal } from './RoleSwitcherModal';
import {
  GraduationCap,
  Bell,
  RefreshCw,
  Smartphone,
  Monitor,
  Tablet,
  Sparkles,
  Globe,
  Crown,
  Building2,
} from 'lucide-react';

interface Props {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  deviceMode: 'desktop' | 'tablet' | 'mobile';
  setDeviceMode: (mode: 'desktop' | 'tablet' | 'mobile') => void;
  onOpenReportCard?: () => void;
  onOpenHonorRoll?: () => void;
}

export const Navbar: React.FC<Props> = ({
  activeTab,
  setActiveTab,
  deviceMode,
  setDeviceMode,
  onOpenReportCard,
  onOpenHonorRoll,
}) => {
  const {
    currentUser,
    currentRole,
    announcements,
    attendance,
    schools,
    activeSchool,
    resetToDefaults,
    language,
    toggleLanguage,
    t,
  } = useSchool();

  const [showRoleModal, setShowRoleModal] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  // Compute urgent alerts
  const urgentAnnouncements = announcements.filter((a) => a.priority === 'urgent');
  const todayAbsences = attendance.filter((a) => a.date === '2026-10-28' && a.status === 'absent');

  const getRoleConfig = () => {
    switch (currentRole) {
      case 'super_admin':
        return { label: t('superAdminRole'), color: 'bg-amber-100 text-amber-900 border-amber-300 font-black' };
      case 'admin':
        return { label: t('adminRole'), color: 'bg-purple-100 text-purple-800 border-purple-200' };
      case 'teacher':
        return { label: t('teacherRole'), color: 'bg-emerald-100 text-emerald-800 border-emerald-200' };
      case 'student':
        return { label: t('studentRole'), color: 'bg-blue-100 text-blue-800 border-blue-200' };
      case 'parent':
        return { label: t('parentRole'), color: 'bg-amber-100 text-amber-800 border-amber-200' };
    }
  };

  const roleConfig = getRoleConfig();

  return (
    <>
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 h-16 flex items-center justify-between gap-3">
          {/* Logo & Institute Name */}
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-2xl flex items-center justify-center text-white shadow-md shrink-0 ${
              currentRole === 'super_admin'
                ? 'bg-gradient-to-tr from-amber-600 via-orange-500 to-yellow-400 shadow-amber-500/25 ring-2 ring-amber-300'
                : 'bg-gradient-to-tr from-blue-700 via-indigo-600 to-sky-500 shadow-blue-500/20'
            }`}>
              {currentRole === 'super_admin' ? (
                <Crown className="w-5 h-5 text-white" />
              ) : (
                <GraduationCap className="w-6 h-6 text-white" />
              )}
            </div>
            <div className="cursor-pointer" onClick={() => setActiveTab('dashboard')}>
              <div className="flex items-center gap-1.5">
                <span className="font-black text-slate-900 text-base sm:text-lg tracking-tight">
                  {currentRole === 'super_admin'
                    ? language === 'ar'
                      ? 'بوابة المالك العام (Super Admin)'
                      : 'Platform Owner Portal'
                    : language === 'ar'
                    ? activeSchool.name
                    : activeSchool.nameEn || activeSchool.name}
                </span>
                <span className="hidden sm:inline-flex items-center px-1.5 py-0.5 text-[10px] font-bold bg-blue-50 text-blue-700 rounded-md border border-blue-200/60">
                  {t('pwaBadge')}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 hidden sm:block">
                {currentRole === 'super_admin'
                  ? language === 'ar'
                    ? `إدارة ${schools.length} مدارس ومعاهد مسجلة`
                    : `Managing ${schools.length} registered schools & institutes`
                  : t('appSubtitle')}
              </p>
            </div>
          </div>

          {/* Device Preview Switcher (Desktop / Tablet / Mobile simulator) */}
          <div className="hidden lg:flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 text-slate-600 text-xs font-semibold">
            <button
              onClick={() => setDeviceMode('desktop')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg transition ${
                deviceMode === 'desktop'
                  ? 'bg-white text-blue-700 shadow-xs font-bold'
                  : 'hover:text-slate-900'
              }`}
              title={t('desktopView')}
            >
              <Monitor className="w-3.5 h-3.5" />
              <span>{t('desktopView')}</span>
            </button>
            <button
              onClick={() => setDeviceMode('tablet')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg transition ${
                deviceMode === 'tablet'
                  ? 'bg-white text-blue-700 shadow-xs font-bold'
                  : 'hover:text-slate-900'
              }`}
              title={t('tabletView')}
            >
              <Tablet className="w-3.5 h-3.5" />
              <span>{t('tabletView')}</span>
            </button>
            <button
              onClick={() => setDeviceMode('mobile')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg transition ${
                deviceMode === 'mobile'
                  ? 'bg-white text-blue-700 shadow-xs font-bold'
                  : 'hover:text-slate-900'
              }`}
              title={t('mobileView')}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>{t('mobileView')}</span>
            </button>
          </div>

          {/* Actions: Language switcher, Honor roll, PWA install, Notifications, Account Switch */}
          <div className="flex items-center gap-2">
            {/* Language Switcher Button (AR / EN) */}
            <button
              onClick={toggleLanguage}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300/80 transition active:scale-95 shadow-xs"
              title="تغيير اللغة / Change Language"
            >
              <Globe className="w-4 h-4 text-blue-600" />
              <span>{language === 'ar' ? 'English 🇬🇧' : 'عربي 🇸🇦'}</span>
            </button>

            {/* Honor Roll */}
            {onOpenHonorRoll && (
              <button
                onClick={onOpenHonorRoll}
                className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-amber-50 text-amber-800 border border-amber-200/70 hover:bg-amber-100 transition"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                <span>{t('honorRoll')}</span>
              </button>
            )}

            {/* PWA Install Button */}
            <PWAInstallButton />

            {/* Notifications Dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowNotifications(!showNotifications)}
                className="relative p-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition"
                title="Notifications"
              >
                <Bell className="w-5 h-5" />
                {urgentAnnouncements.length > 0 && (
                  <span className="absolute top-1 right-1 w-2.5 h-2.5 rounded-full bg-rose-500 ring-2 ring-white" />
                )}
              </button>

              {showNotifications && (
                <div className={`absolute ${language === 'ar' ? 'left-0 sm:left-auto sm:right-0' : 'right-0 sm:right-auto sm:left-0'} mt-2 w-80 sm:w-96 rounded-2xl bg-white shadow-2xl border border-slate-200 p-4 z-50 animate-fadeIn`}>
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                    <h4 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                      <Bell className="w-4 h-4 text-blue-600" />
                      <span>{language === 'ar' ? 'مركز التنبيهات الفورية' : 'Instant Alerts Center'}</span>
                    </h4>
                    <span className="text-[11px] font-semibold text-slate-400">
                      {language === 'ar' ? 'اليوم' : 'Today'}
                    </span>
                  </div>

                  <div className="space-y-2.5 my-3 max-h-72 overflow-y-auto">
                    {urgentAnnouncements.map((a) => (
                      <div
                        key={a.id}
                        className="p-3 rounded-xl bg-amber-50 border border-amber-200/80 text-xs"
                      >
                        <div className="flex items-center justify-between font-bold text-amber-900 mb-1">
                          <span>{language === 'ar' ? a.title : a.titleEn || a.title}</span>
                          <span className="text-[10px] bg-amber-200 text-amber-900 px-1.5 py-0.5 rounded">
                            {t('urgent')}
                          </span>
                        </div>
                        <p className="text-amber-800/90 leading-relaxed">
                          {language === 'ar' ? a.content : a.contentEn || a.content}
                        </p>
                      </div>
                    ))}

                    <div className="p-3 rounded-xl bg-blue-50 border border-blue-200/70 text-xs">
                      <div className="font-bold text-blue-900 mb-0.5">
                        {language === 'ar' ? 'سجل الحضور اليومي مفعل' : 'Daily Attendance Active'}
                      </div>
                      <p className="text-blue-800">
                        {language === 'ar'
                          ? `تم رصد حضور اليوم بنجاح، وعدد المتغيبين ${todayAbsences.length} طلاب.`
                          : `Today's attendance recorded. ${todayAbsences.length} student(s) absent.`}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => setShowNotifications(false)}
                    className="w-full py-1.5 text-center text-xs text-slate-500 hover:text-slate-700 font-semibold border-t border-slate-100"
                  >
                    {t('close')}
                  </button>
                </div>
              )}
            </div>

            {/* Active User & Switch Account Button */}
            <div
              onClick={() => setShowRoleModal(true)}
              className="flex items-center gap-2 p-1.5 px-3 rounded-2xl bg-slate-100 hover:bg-slate-200 cursor-pointer border border-slate-200/80 transition"
              title={t('switchRole')}
            >
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="w-8 h-8 rounded-xl object-cover ring-2 ring-white"
              />
              <div className="hidden sm:block">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-bold text-slate-900 truncate max-w-[120px]">
                    {language === 'ar' ? currentUser.name : currentUser.nameEn || currentUser.name}
                  </span>
                  <span
                    className={`text-[10px] font-extrabold px-1.5 py-0.2 rounded-md border ${roleConfig.color}`}
                  >
                    {roleConfig.label}
                  </span>
                </div>
                <span className="text-[10px] text-blue-600 font-semibold block">
                  {t('switchRole')} ↺
                </span>
              </div>
            </div>

            {/* Reset data */}
            <button
              onClick={() => {
                if (window.confirm(t('resetConfirm'))) {
                  resetToDefaults();
                }
              }}
              className="p-2 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 transition hidden sm:flex"
              title={t('resetData')}
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Role Switcher Modal */}
      <RoleSwitcherModal isOpen={showRoleModal} onClose={() => setShowRoleModal(false)} />
    </>
  );
};
