import React from 'react';
import { useSchool } from '../../context/SchoolContext';
import { UserRole } from '../../types';
import { DEMO_USERS } from '../../data/mockData';
import { ShieldCheck, GraduationCap, BookOpen, Users, Check, X, Crown } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const RoleSwitcherModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const { currentRole, switchUser, language, t } = useSchool();

  if (!isOpen) return null;

  const rolesConfig: Array<{
    role: UserRole;
    label: string;
    subLabel: string;
    description: string;
    icon: React.ReactNode;
    color: string;
    badgeColor: string;
  }> = [
    {
      role: 'super_admin',
      label: t('superAdminRole'),
      subLabel: language === 'ar' ? DEMO_USERS.super_admin.name : DEMO_USERS.super_admin.nameEn || DEMO_USERS.super_admin.name,
      description:
        language === 'ar'
          ? 'المالك والمشرف العام على المنظومة: فتح وإدارة حسابات المدارس والمعاهد، تحديد الباقات، وبث التعاميم لجميع الفروع.'
          : 'Platform Owner & Super Admin: Provision multi-school accounts, configure subscription quotas, and broadcast global notices.',
      icon: <Crown className="w-6 h-6 text-amber-600" />,
      color: 'border-amber-400 bg-amber-50/70 hover:bg-amber-100/60 ring-amber-400/40',
      badgeColor: 'bg-amber-200 text-amber-900 font-black',
    },
    {
      role: 'teacher',
      label: t('teacherRole'),
      subLabel: language === 'ar' ? DEMO_USERS.teacher.name : DEMO_USERS.teacher.nameEn || DEMO_USERS.teacher.name,
      description:
        language === 'ar'
          ? 'نشر الدرجات والاختبارات، إرسال الواجبات وتصحيحها، وتسجيل الحضور والغياب بضغطة زر.'
          : 'Publish grades, create & grade homework assignments with attachments, and take daily attendance.',
      icon: <GraduationCap className="w-6 h-6 text-emerald-600" />,
      color: 'border-emerald-500 bg-emerald-50/50 hover:bg-emerald-50',
      badgeColor: 'bg-emerald-100 text-emerald-800',
    },
    {
      role: 'admin',
      label: t('adminRole'),
      subLabel: language === 'ar' ? DEMO_USERS.admin.name : DEMO_USERS.admin.nameEn || DEMO_USERS.admin.name,
      description:
        language === 'ar'
          ? 'لوحة القيادة المدرسية: إنشاء وتوليد حسابات المعلمين والطلاب والأهل مع الربط التلقائي، وتعديل الدرجات والجدول.'
          : 'School Principal portal: provision accounts for teachers, students & parents with auto-linking, and edit grades & timetable.',
      icon: <ShieldCheck className="w-6 h-6 text-purple-600" />,
      color: 'border-purple-500 bg-purple-50/50 hover:bg-purple-50',
      badgeColor: 'bg-purple-100 text-purple-800',
    },
    {
      role: 'student',
      label: t('studentRole'),
      subLabel: language === 'ar' ? DEMO_USERS.student.name : DEMO_USERS.student.nameEn || DEMO_USERS.student.name,
      description:
        language === 'ar'
          ? 'كشف الدرجات حسب المواد (زر +)، تسليم الواجبات بالصور والملفات، وسجل الحضور والجدول.'
          : 'Transcripts by subject (+ button), submit homework with photos & files, attendance log, and schedule.',
      icon: <BookOpen className="w-6 h-6 text-blue-600" />,
      color: 'border-blue-500 bg-blue-50/50 hover:bg-blue-50',
      badgeColor: 'bg-blue-100 text-blue-800',
    },
    {
      role: 'parent',
      label: t('parentRole'),
      subLabel: language === 'ar' ? DEMO_USERS.parent.name : DEMO_USERS.parent.nameEn || DEMO_USERS.parent.name,
      description:
        language === 'ar'
          ? 'متابعة أداء وغياب الأبناء (يوسف وسارة)، تقديم استئذانات، والتواصل المباشر مع المعلمين.'
          : 'Monitor multiple children (Yousef & Sarah), instant absence alerts, request leaves, and chat with teachers.',
      icon: <Users className="w-6 h-6 text-indigo-600" />,
      color: 'border-indigo-500 bg-indigo-50/50 hover:bg-indigo-50',
      badgeColor: 'bg-indigo-100 text-indigo-800',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-fadeIn">
      <div className="relative w-full max-w-xl rounded-2xl bg-white p-6 shadow-2xl border border-slate-100 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div>
            <h2 className="text-xl font-black text-slate-900">
              {language === 'ar' ? 'تبديل نوع الحساب التجريبي' : 'Switch Demo Account'}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              {language === 'ar'
                ? 'اختر دورك لتجربة المزايا المخصصة لكل طرف (إدارة، مدرسين، طلاب، أولياء الأمور)'
                : 'Select a portal to explore specialized features for each role'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4">
          {rolesConfig.map((item) => {
            const isSelected = currentRole === item.role;
            return (
              <div
                key={item.role}
                onClick={() => {
                  switchUser(item.role);
                  onClose();
                }}
                className={`p-4 rounded-xl border-2 cursor-pointer transition-all flex flex-col justify-between relative ${
                  isSelected
                    ? `${item.color} shadow-sm ring-2 ring-blue-500/20`
                    : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50/50'
                }`}
              >
                {isSelected && (
                  <span className={`absolute top-3 ${language === 'ar' ? 'left-3' : 'right-3'} w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center`}>
                    <Check className="w-3 h-3 stroke-[3]" />
                  </span>
                )}
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="p-2 rounded-xl bg-white shadow-xs border border-slate-100">
                      {item.icon}
                    </div>
                    <div>
                      <span className={`text-[11px] font-bold px-2 py-0.5 rounded-md ${item.badgeColor}`}>
                        {item.label}
                      </span>
                      <h4 className="font-bold text-sm text-slate-900 mt-0.5">{item.subLabel}</h4>
                    </div>
                  </div>
                  <p className="text-xs text-slate-500 leading-relaxed mt-2">{item.description}</p>
                </div>

                <div className="mt-3 pt-2.5 border-t border-slate-100/80 flex items-center justify-between text-xs font-semibold text-blue-600">
                  <span>
                    {isSelected
                      ? language === 'ar'
                        ? 'الحساب النشط حالياً'
                        : 'Active Account'
                      : language === 'ar'
                      ? 'دخول بهذا الحساب'
                      : 'Switch to this account'}
                  </span>
                  <span>{language === 'ar' ? '←' : '→'}</span>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400">
          <span>
            {language === 'ar'
              ? '* يتم حفظ وتزامن كافة البيانات والدرجات محلياً'
              : '* All grades, attendance, and homework data are synced'}
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition"
          >
            {t('close')}
          </button>
        </div>
      </div>
    </div>
  );
};
