import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  UserProfile,
  UserRole,
  Student,
  Teacher,
  ParentAccount,
  GradeItem,
  Homework,
  AttendanceRecord,
  TimetableEntry,
  SchoolAnnouncement,
  LeaveRequest,
  ChatMessage,
  AttendanceStatus,
  AppLanguage,
  FileAttachment,
  School,
} from '../types';
import {
  DEMO_USERS,
  INITIAL_STUDENTS,
  INITIAL_TEACHERS,
  INITIAL_PARENTS,
  INITIAL_GRADES,
  INITIAL_HOMEWORK,
  INITIAL_ATTENDANCE,
  INITIAL_TIMETABLE,
  INITIAL_ANNOUNCEMENTS,
  INITIAL_LEAVE_REQUESTS,
  INITIAL_MESSAGES,
  INITIAL_SCHOOLS,
} from '../data/mockData';
import { translations, TranslationKey } from '../i18n/translations';

interface SchoolContextType {
  currentUser: UserProfile;
  currentRole: UserRole;
  switchUser: (role: UserRole) => void;
  impersonateAccount: (role: UserRole, targetId?: string) => void;
  activeChildId: string;
  setActiveChildId: (id: string) => void;

  // Language & i18n
  language: AppLanguage;
  toggleLanguage: () => void;
  setLanguage: (lang: AppLanguage) => void;
  t: (key: TranslationKey) => string;

  // Multi-School & Super Admin
  schools: School[];
  activeSchoolId: string;
  activeSchool: School;
  setActiveSchoolId: (id: string) => void;
  addSchool: (school: Omit<School, 'id' | 'createdAt' | 'studentsCount' | 'teachersCount' | 'storageUsedGb'>) => void;
  toggleSchoolStatus: (schoolId: string) => void;
  deleteSchool: (schoolId: string) => void;
  manageSchoolAsAdmin: (schoolId: string) => void;
  
  // School Data Collections
  students: Student[];
  teachers: Teacher[];
  parents: ParentAccount[];
  grades: GradeItem[];
  homeworkList: Homework[];
  attendance: AttendanceRecord[];
  timetable: TimetableEntry[];
  announcements: SchoolAnnouncement[];
  leaveRequests: LeaveRequest[];
  messages: ChatMessage[];

  // Principal Account Provisioning
  addTeacher: (teacher: Omit<Teacher, 'id'>) => Teacher;
  updateTeacher: (id: string, updated: Partial<Teacher>) => void;
  deleteTeacher: (id: string) => void;
  
  addStudentWithParent: (
    studentData: {
      name: string;
      nameEn?: string;
      nationalId: string;
      className: string;
      classNameEn?: string;
      avatar?: string;
      gpa?: number;
      rankInClass?: number;
    },
    parentData: {
      isExistingParent: boolean;
      existingParentId?: string;
      parentName: string;
      parentNameEn?: string;
      parentPhone: string;
      parentEmail: string;
      parentNationalId?: string;
      relationship?: string;
    }
  ) => { student: Student; parent: ParentAccount; isNewParent: boolean };
  
  updateStudent: (id: string, updated: Partial<Student>) => void;
  deleteStudent: (id: string) => void;
  
  addParent: (parent: Omit<ParentAccount, 'id' | 'childrenIds'> & { childrenIds?: string[] }) => ParentAccount;
  deleteParent: (id: string) => void;

  // Actions
  addGrade: (grade: Omit<GradeItem, 'id'>) => void;
  updateGrade: (id: string, updated: Partial<GradeItem>) => void;
  deleteGrade: (id: string) => void;
  
  updateTimetableEntry: (id: string, updated: Partial<TimetableEntry>) => void;
  addTimetableEntry: (entry: Omit<TimetableEntry, 'id'>) => void;
  deleteTimetableEntry: (id: string) => void;
  
  addHomework: (hw: Omit<Homework, 'id' | 'submissions'>) => void;
  submitHomework: (homeworkId: string, content: string, attachments?: FileAttachment[], fileAttachment?: string) => void;
  gradeHomeworkSubmission: (homeworkId: string, submissionId: string, score: number, teacherNotes: string) => void;

  recordAttendance: (record: Omit<AttendanceRecord, 'id'>) => void;
  batchRecordAttendance: (records: Array<Omit<AttendanceRecord, 'id'>>) => void;

  createLeaveRequest: (req: Omit<LeaveRequest, 'id' | 'status' | 'requestDate'>) => void;
  updateLeaveRequestStatus: (id: string, status: 'approved' | 'rejected', adminResponse?: string) => void;

  addAnnouncement: (ann: Omit<SchoolAnnouncement, 'id' | 'date'>) => void;
  sendMessage: (recipientId: string, content: string) => void;

  resetToDefaults: () => void;
}

const SchoolContext = createContext<SchoolContextType | undefined>(undefined);

const STORAGE_PREFIX = 'madrasati_pwa_v3_';

export const SchoolProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Language State
  const [language, setLanguageState] = useState<AppLanguage>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}lang`);
    return (saved as AppLanguage) || 'ar';
  });

  const setLanguage = (lang: AppLanguage) => {
    setLanguageState(lang);
    localStorage.setItem(`${STORAGE_PREFIX}lang`, lang);
  };

  const toggleLanguage = () => {
    const nextLang = language === 'ar' ? 'en' : 'ar';
    setLanguage(nextLang);
  };

  useEffect(() => {
    document.documentElement.lang = language;
    // Layout direction remains fixed to RTL regardless of language changes per requirements
    document.documentElement.dir = 'rtl';
  }, [language]);

  const t = (key: TranslationKey): string => {
    return translations[language][key] || key;
  };

  // Multi-School State (Super Admin)
  const [schools, setSchools] = useState<School[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}schools`);
    return saved ? JSON.parse(saved) : INITIAL_SCHOOLS;
  });

  const [activeSchoolId, setActiveSchoolId] = useState<string>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}activeSchoolId`);
    return saved || 'sch_1';
  });

  const activeSchool = schools.find((s) => s.id === activeSchoolId) || schools[0];

  // Current active role & user
  const [currentRole, setCurrentRole] = useState<UserRole>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}role`);
    return (saved as UserRole) || 'super_admin'; // Default to super_admin so the user immediately sees the requested Super Admin dashboard!
  });

  // Selected child for parent portal
  const [activeChildId, setActiveChildId] = useState<string>('std_1');

  // Database collections with localStorage persistence
  const [students, setStudents] = useState<Student[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}students`);
    return saved ? JSON.parse(saved) : INITIAL_STUDENTS;
  });

  const [teachers, setTeachers] = useState<Teacher[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}teachers`);
    return saved ? JSON.parse(saved) : INITIAL_TEACHERS;
  });

  const [parents, setParents] = useState<ParentAccount[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}parents`);
    return saved ? JSON.parse(saved) : INITIAL_PARENTS;
  });

  const currentParent = parents.find((p) => p.childrenIds.includes(activeChildId)) || parents[0];
  const currentUser: UserProfile = {
    ...(DEMO_USERS[currentRole] || DEMO_USERS.super_admin),
    ...(currentRole === 'parent' && currentParent
      ? {
          id: currentParent.id,
          name: currentParent.name,
          nameEn: currentParent.nameEn,
          email: currentParent.email,
          phone: currentParent.phone,
          childrenIds: currentParent.childrenIds,
        }
      : {}),
  };

  const [grades, setGrades] = useState<GradeItem[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}grades`);
    return saved ? JSON.parse(saved) : INITIAL_GRADES;
  });

  const [homeworkList, setHomeworkList] = useState<Homework[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}homework`);
    return saved ? JSON.parse(saved) : INITIAL_HOMEWORK;
  });

  const [attendance, setAttendance] = useState<AttendanceRecord[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}attendance`);
    return saved ? JSON.parse(saved) : INITIAL_ATTENDANCE;
  });

  const [timetable, setTimetable] = useState<TimetableEntry[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}timetable`);
    return saved ? JSON.parse(saved) : INITIAL_TIMETABLE;
  });

  const [announcements, setAnnouncements] = useState<SchoolAnnouncement[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}announcements`);
    return saved ? JSON.parse(saved) : INITIAL_ANNOUNCEMENTS;
  });

  const [leaveRequests, setLeaveRequests] = useState<LeaveRequest[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}leaveRequests`);
    return saved ? JSON.parse(saved) : INITIAL_LEAVE_REQUESTS;
  });

  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}messages`);
    return saved ? JSON.parse(saved) : INITIAL_MESSAGES;
  });

  // Sync state to LocalStorage
  useEffect(() => {
    localStorage.setItem(`${STORAGE_PREFIX}role`, currentRole);
  }, [currentRole]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_PREFIX}schools`, JSON.stringify(schools));
  }, [schools]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_PREFIX}activeSchoolId`, activeSchoolId);
  }, [activeSchoolId]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_PREFIX}students`, JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_PREFIX}teachers`, JSON.stringify(teachers));
  }, [teachers]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_PREFIX}parents`, JSON.stringify(parents));
  }, [parents]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_PREFIX}grades`, JSON.stringify(grades));
  }, [grades]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_PREFIX}homework`, JSON.stringify(homeworkList));
  }, [homeworkList]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_PREFIX}attendance`, JSON.stringify(attendance));
  }, [attendance]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_PREFIX}announcements`, JSON.stringify(announcements));
  }, [announcements]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_PREFIX}leaveRequests`, JSON.stringify(leaveRequests));
  }, [leaveRequests]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_PREFIX}messages`, JSON.stringify(messages));
  }, [messages]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_PREFIX}timetable`, JSON.stringify(timetable));
  }, [timetable]);

  const switchUser = (role: UserRole) => {
    setCurrentRole(role);
  };

  const impersonateAccount = (role: UserRole, targetId?: string) => {
    setCurrentRole(role);
    if (role === 'parent' && targetId) {
      const p = parents.find((item) => item.id === targetId);
      if (p && p.childrenIds.length > 0) {
        setActiveChildId(p.childrenIds[0]);
      }
    } else if (role === 'student' && targetId) {
      setActiveChildId(targetId);
    }
  };

  // Super Admin: Add new school facility
  const addSchool = (
    schoolData: Omit<School, 'id' | 'createdAt' | 'studentsCount' | 'teachersCount' | 'storageUsedGb'>
  ) => {
    const newSchool: School = {
      ...schoolData,
      id: `sch_${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0],
      studentsCount: 150,
      teachersCount: 12,
      storageUsedGb: 1.5,
    };
    setSchools((prev) => [newSchool, ...prev]);
  };

  const toggleSchoolStatus = (schoolId: string) => {
    setSchools((prev) =>
      prev.map((s) =>
        s.id === schoolId ? { ...s, status: s.status === 'active' ? 'suspended' : 'active' } : s
      )
    );
  };

  const deleteSchool = (schoolId: string) => {
    setSchools((prev) => prev.filter((s) => s.id !== schoolId));
  };

  const manageSchoolAsAdmin = (schoolId: string) => {
    setActiveSchoolId(schoolId);
    setCurrentRole('admin');
  };

  // Principal Accounts Provisioning & Management
  const addTeacher = (teacherData: Omit<Teacher, 'id'>): Teacher => {
    const newTeacher: Teacher = {
      ...teacherData,
      id: `tch_${Date.now()}`,
      schoolId: activeSchoolId,
    };
    setTeachers((prev) => [newTeacher, ...prev]);
    return newTeacher;
  };

  const updateTeacher = (id: string, updated: Partial<Teacher>) => {
    setTeachers((prev) => prev.map((t) => (t.id === id ? { ...t, ...updated } : t)));
  };

  const deleteTeacher = (id: string) => {
    setTeachers((prev) => prev.filter((t) => t.id !== id));
  };

  const addStudentWithParent = (
    studentData: {
      name: string;
      nameEn?: string;
      nationalId: string;
      className: string;
      classNameEn?: string;
      avatar?: string;
      gpa?: number;
      rankInClass?: number;
    },
    parentData: {
      isExistingParent: boolean;
      existingParentId?: string;
      parentName: string;
      parentNameEn?: string;
      parentPhone: string;
      parentEmail: string;
      parentNationalId?: string;
      relationship?: string;
    }
  ) => {
    const studentId = `std_${Date.now()}`;
    let resolvedParentId = '';
    let resolvedParentName = '';
    let resolvedParentPhone = '';
    let resolvedParent: ParentAccount;
    let isNewParent = false;

    if (parentData.isExistingParent && parentData.existingParentId) {
      const existing = parents.find((p) => p.id === parentData.existingParentId);
      if (existing) {
        resolvedParentId = existing.id;
        resolvedParentName = existing.name;
        resolvedParentPhone = existing.phone;
        resolvedParent = {
          ...existing,
          childrenIds: [...new Set([...existing.childrenIds, studentId])],
        };
        setParents((prev) =>
          prev.map((p) => (p.id === existing.id ? resolvedParent : p))
        );
      } else {
        resolvedParentId = `parent_${Date.now()}`;
        resolvedParentName = parentData.parentName;
        resolvedParentPhone = parentData.parentPhone;
        resolvedParent = {
          id: resolvedParentId,
          name: parentData.parentName,
          nameEn: parentData.parentNameEn || parentData.parentName,
          email: parentData.parentEmail,
          phone: parentData.parentPhone,
          nationalId: parentData.parentNationalId,
          childrenIds: [studentId],
          avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
          schoolId: activeSchoolId,
          relationship: parentData.relationship || 'ولي أمر (أب)',
          createdAt: new Date().toISOString().split('T')[0],
        };
        setParents((prev) => [resolvedParent, ...prev]);
        isNewParent = true;
      }
    } else {
      resolvedParentId = `parent_${Date.now()}`;
      resolvedParentName = parentData.parentName;
      resolvedParentPhone = parentData.parentPhone;
      resolvedParent = {
        id: resolvedParentId,
        name: parentData.parentName,
        nameEn: parentData.parentNameEn || parentData.parentName,
        email: parentData.parentEmail,
        phone: parentData.parentPhone,
        nationalId: parentData.parentNationalId,
        childrenIds: [studentId],
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
        schoolId: activeSchoolId,
        relationship: parentData.relationship || 'ولي أمر (أب)',
        createdAt: new Date().toISOString().split('T')[0],
      };
      setParents((prev) => [resolvedParent, ...prev]);
      isNewParent = true;
    }

    const newStudent: Student = {
      id: studentId,
      name: studentData.name,
      nameEn: studentData.nameEn || studentData.name,
      nationalId: studentData.nationalId,
      className: studentData.className,
      classNameEn: studentData.classNameEn || studentData.className,
      avatar:
        studentData.avatar ||
        'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80',
      parentId: resolvedParentId,
      parentName: resolvedParentName,
      parentPhone: resolvedParentPhone,
      gpa: studentData.gpa ?? 95.0,
      rankInClass: studentData.rankInClass ?? (students.length + 1),
      totalAbsences: 0,
      badges: ['طالب جديد', 'عضو مسجل بالمنظومة'],
      schoolId: activeSchoolId,
    };

    setStudents((prev) => [newStudent, ...prev]);

    return { student: newStudent, parent: resolvedParent, isNewParent };
  };

  const updateStudent = (id: string, updated: Partial<Student>) => {
    setStudents((prev) => prev.map((s) => (s.id === id ? { ...s, ...updated } : s)));
  };

  const deleteStudent = (id: string) => {
    setStudents((prev) => prev.filter((s) => s.id !== id));
  };

  const addParent = (
    parentData: Omit<ParentAccount, 'id' | 'childrenIds'> & { childrenIds?: string[] }
  ): ParentAccount => {
    const newParent: ParentAccount = {
      ...parentData,
      id: `parent_${Date.now()}`,
      childrenIds: parentData.childrenIds || [],
      schoolId: activeSchoolId,
      createdAt: new Date().toISOString().split('T')[0],
    };
    setParents((prev) => [newParent, ...prev]);
    return newParent;
  };

  const deleteParent = (id: string) => {
    setParents((prev) => prev.filter((p) => p.id !== id));
  };

  // Grade Mutations
  const addGrade = (grade: Omit<GradeItem, 'id'>) => {
    const newGrade: GradeItem = {
      ...grade,
      id: `grd_${Date.now()}`,
      schoolId: activeSchoolId,
    };
    setGrades((prev) => [newGrade, ...prev]);

    setStudents((prevStudents) =>
      prevStudents.map((std) => {
        if (std.id === grade.studentId) {
          const studentGrades = [newGrade, ...grades.filter((g) => g.studentId === std.id)];
          const totalEarned = studentGrades.reduce((sum, g) => sum + (g.score / g.maxScore) * 100, 0);
          const avg = Number((totalEarned / studentGrades.length).toFixed(1));
          return { ...std, gpa: avg };
        }
        return std;
      })
    );
  };

  const updateGrade = (id: string, updated: Partial<GradeItem>) => {
    setGrades((prev) => {
      const updatedGrades = prev.map((g) => (g.id === id ? { ...g, ...updated } : g));
      const targetGrade = updatedGrades.find((g) => g.id === id);
      if (targetGrade) {
        const studentGrades = updatedGrades.filter((g) => g.studentId === targetGrade.studentId);
        const totalEarned = studentGrades.reduce((sum, g) => sum + (g.score / g.maxScore) * 100, 0);
        const avg = studentGrades.length > 0 ? Number((totalEarned / studentGrades.length).toFixed(1)) : 100;
        setStudents((sPrev) =>
          sPrev.map((s) => (s.id === targetGrade.studentId ? { ...s, gpa: avg } : s))
        );
      }
      return updatedGrades;
    });
  };

  const deleteGrade = (id: string) => {
    setGrades((prev) => {
      const target = prev.find((g) => g.id === id);
      const filtered = prev.filter((g) => g.id !== id);
      if (target) {
        const studentGrades = filtered.filter((g) => g.studentId === target.studentId);
        const totalEarned = studentGrades.reduce((sum, g) => sum + (g.score / g.maxScore) * 100, 0);
        const avg = studentGrades.length > 0 ? Number((totalEarned / studentGrades.length).toFixed(1)) : 100;
        setStudents((sPrev) =>
          sPrev.map((s) => (s.id === target.studentId ? { ...s, gpa: avg } : s))
        );
      }
      return filtered;
    });
  };

  // Timetable Mutations (Principal / School Admin)
  const updateTimetableEntry = (id: string, updated: Partial<TimetableEntry>) => {
    setTimetable((prev) =>
      prev.map((entry) => (entry.id === id ? { ...entry, ...updated } : entry))
    );
  };

  const addTimetableEntry = (entry: Omit<TimetableEntry, 'id'>) => {
    const newEntry: TimetableEntry = {
      ...entry,
      id: `tt_${Date.now()}`,
      schoolId: activeSchoolId,
    };
    setTimetable((prev) => [...prev, newEntry]);
  };

  const deleteTimetableEntry = (id: string) => {
    setTimetable((prev) => prev.filter((entry) => entry.id !== id));
  };

  // Homework Mutations
  const addHomework = (hw: Omit<Homework, 'id' | 'submissions'>) => {
    const newHomework: Homework = {
      ...hw,
      id: `hw_${Date.now()}`,
      submissions: [],
      schoolId: activeSchoolId,
    };
    setHomeworkList((prev) => [newHomework, ...prev]);
  };

  const submitHomework = (
    homeworkId: string,
    content: string,
    attachments?: FileAttachment[],
    fileAttachment?: string
  ) => {
    const submissionId = `sub_${Date.now()}`;
    const student = students.find((s) => s.id === currentUser.id) || students[0];

    setHomeworkList((prev) =>
      prev.map((hw) => {
        if (hw.id === homeworkId) {
          const filteredSubmissions = hw.submissions.filter((s) => s.studentId !== student.id);
          const newSub = {
            id: submissionId,
            studentId: student.id,
            studentName: student.name,
            submittedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
            content,
            fileAttachment: fileAttachment || (attachments && attachments[0]?.name),
            attachments: attachments || [],
            status: 'pending' as const,
            maxScore: hw.maxScore,
          };
          return {
            ...hw,
            submissions: [newSub, ...filteredSubmissions],
          };
        }
        return hw;
      })
    );
  };

  const gradeHomeworkSubmission = (
    homeworkId: string,
    submissionId: string,
    score: number,
    teacherNotes: string
  ) => {
    setHomeworkList((prev) =>
      prev.map((hw) => {
        if (hw.id === homeworkId) {
          return {
            ...hw,
            submissions: hw.submissions.map((sub) => {
              if (sub.id === submissionId) {
                return {
                  ...sub,
                  status: 'graded' as const,
                  score,
                  teacherNotes,
                };
              }
              return sub;
            }),
          };
        }
        return hw;
      })
    );
  };

  // Attendance Mutations
  const recordAttendance = (rec: Omit<AttendanceRecord, 'id'>) => {
    const newRecord: AttendanceRecord = {
      ...rec,
      id: `att_${Date.now()}`,
      schoolId: activeSchoolId,
    };
    setAttendance((prev) => {
      const existingFiltered = prev.filter(
        (a) => !(a.studentId === rec.studentId && a.date === rec.date)
      );
      return [newRecord, ...existingFiltered];
    });

    if (rec.status === 'absent') {
      setStudents((prev) =>
        prev.map((s) => (s.id === rec.studentId ? { ...s, totalAbsences: s.totalAbsences + 1 } : s))
      );
    }
  };

  const batchRecordAttendance = (records: Array<Omit<AttendanceRecord, 'id'>>) => {
    const newItems: AttendanceRecord[] = records.map((r, idx) => ({
      ...r,
      id: `att_${Date.now()}_${idx}`,
      schoolId: activeSchoolId,
    }));

    setAttendance((prev) => {
      const keysToReplace = new Set(records.map((r) => `${r.studentId}_${r.date}`));
      const retained = prev.filter((a) => !keysToReplace.has(`${a.studentId}_${a.date}`));
      return [...newItems, ...retained];
    });
  };

  // Leave Requests
  const createLeaveRequest = (req: Omit<LeaveRequest, 'id' | 'status' | 'requestDate'>) => {
    const newReq: LeaveRequest = {
      ...req,
      id: `lr_${Date.now()}`,
      status: 'pending',
      requestDate: new Date().toISOString().split('T')[0],
      schoolId: activeSchoolId,
    };
    setLeaveRequests((prev) => [newReq, ...prev]);
  };

  const updateLeaveRequestStatus = (
    id: string,
    status: 'approved' | 'rejected',
    adminResponse?: string
  ) => {
    setLeaveRequests((prev) =>
      prev.map((r) => {
        if (r.id === id) {
          return {
            ...r,
            status,
            adminResponse:
              adminResponse ||
              (status === 'approved'
                ? language === 'ar'
                  ? 'تمت الموافقة من إدارة المعهد'
                  : 'Approved by School Administration'
                : language === 'ar'
                ? 'تم الرفض لعدم كفاية المبررات'
                : 'Rejected'),
          };
        }
        return r;
      })
    );
  };

  // Announcements
  const addAnnouncement = (ann: Omit<SchoolAnnouncement, 'id' | 'date'>) => {
    const newAnn: SchoolAnnouncement = {
      ...ann,
      id: `ann_${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      schoolId: activeSchoolId,
    };
    setAnnouncements((prev) => [newAnn, ...prev]);
  };

  // Chat / Messages
  const sendMessage = (recipientId: string, content: string) => {
    if (!content.trim()) return;
    const newMsg: ChatMessage = {
      id: `msg_${Date.now()}`,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderRole: currentUser.role,
      recipientId,
      content,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
      schoolId: activeSchoolId,
    };
    setMessages((prev) => [...prev, newMsg]);
  };

  const resetToDefaults = () => {
    localStorage.clear();
    setSchools(INITIAL_SCHOOLS);
    setActiveSchoolId('sch_1');
    setStudents(INITIAL_STUDENTS);
    setTeachers(INITIAL_TEACHERS);
    setParents(INITIAL_PARENTS);
    setGrades(INITIAL_GRADES);
    setHomeworkList(INITIAL_HOMEWORK);
    setAttendance(INITIAL_ATTENDANCE);
    setAnnouncements(INITIAL_ANNOUNCEMENTS);
    setLeaveRequests(INITIAL_LEAVE_REQUESTS);
    setTimetable(INITIAL_TIMETABLE);
    setMessages(INITIAL_MESSAGES);
    setCurrentRole('super_admin');
    setActiveChildId('std_1');
    setLanguage('ar');
  };

  return (
    <SchoolContext.Provider
      value={{
        currentUser,
        currentRole,
        switchUser,
        impersonateAccount,
        activeChildId,
        setActiveChildId,
        language,
        toggleLanguage,
        setLanguage,
        t,
        schools,
        activeSchoolId,
        activeSchool,
        setActiveSchoolId,
        addSchool,
        toggleSchoolStatus,
        deleteSchool,
        manageSchoolAsAdmin,
        students,
        teachers,
        parents,
        addTeacher,
        updateTeacher,
        deleteTeacher,
        addStudentWithParent,
        updateStudent,
        deleteStudent,
        addParent,
        deleteParent,
        grades,
        homeworkList,
        attendance,
        timetable,
        announcements,
        leaveRequests,
        messages,
        addGrade,
        updateGrade,
        deleteGrade,
        updateTimetableEntry,
        addTimetableEntry,
        deleteTimetableEntry,
        addHomework,
        submitHomework,
        gradeHomeworkSubmission,
        recordAttendance,
        batchRecordAttendance,
        createLeaveRequest,
        updateLeaveRequestStatus,
        addAnnouncement,
        sendMessage,
        resetToDefaults,
      }}
    >
      {children}
    </SchoolContext.Provider>
  );
};

export const useSchool = () => {
  const context = useContext(SchoolContext);
  if (!context) {
    throw new Error('useSchool must be used within a SchoolProvider');
  }
  return context;
};
